import axios from "axios";
const RNFS = require("react-native-fs");
const BASIC_URI = "http://39.105.54.161:8080";
export default class GroupChatApi {
    static createGroupChat = async (currentUser, expireDate, roomName, roomId) => {
        console.log(currentUser, expireDate, roomName, roomId);
        let res = await axios.post(`${BASIC_URI}/groupchats`, {
            user: currentUser,
            expireDate,
            name: roomName,
            id: roomId
        }, {
            headers: {
                "Authorization": currentUser.jwt,
            }
        });

        return res.data;
    };
    static getGroupChats = async (currentUser) => {
        let res = await axios.get(`${BASIC_URI}/groupchats`, {
            headers: {
                "Authorization": currentUser.jwt,
            }
        });

        return res.data;
    };

    static uploadImages = async (image) => {
        try {
            let imageDataList;
            if(image !== null && image !== undefined) {
                let list = [];
                for(let item of image) {
                    list.push(await RNFS.readFile(item, "base64"));
                }
                imageDataList = list;
            }
            let res = await axios.post(`${BASIC_URI}/images/multiple`, {
                image: imageDataList,
            });

            console.log(res);
            return res.data;
        } catch (e) {
            console.log(e);
            return [];
        }
    };
    static getGroupChatDetail = async (chat, currentUser) => {
        let res = await axios.get(`${BASIC_URI}/groupchats/${chat}`, {
            headers: {
                "Authorization": currentUser.jwt,
            }
        })
    };
    static updateSnippet = async (message, id, jwt) => {
        let res = await axios.post(`${BASIC_URI}/groupchats/${id}/snippet`, {
            user: {
                id: message._id,
                avatar: message.user.avatar,
                nickname: message.user.name,
            },
            text: message.text,
            image: message.image,
        }, {
            headers: {
                "Authorization": jwt,
            }
        })
    };
    static changeRoomName = () => {

    };
    static changeRoomAvatar = () => {

    };
    static changeRoomExpireDate = () => {

    };
    static modifyGroupChat = async (data, jwt) => {
        let res = await axios.put(`${BASIC_URI}/groupchats/${chat}`, {
            expireDate: data.end_time,
            name: data.title,
        }, {
            headers: {
                "Authorization": jwt,
            }
        })
    };
    static quitGroupChat = () => {

    };
    static addUserToGroupChat = () => {

    };
}
