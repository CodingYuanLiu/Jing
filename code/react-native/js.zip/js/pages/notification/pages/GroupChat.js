import React from "react"
import {View, Text, FlatList, RefreshControl, TouchableNativeFeedback, StyleSheet} from 'react-native';
import {connect} from "react-redux";
import Util from "../../../common/util";
import {addGroupChatMessage, getGroupChatHistory, onGetGroupChats} from "../../../actions/groupChat";
import {Avatar} from "react-native-elements";
import NavigationUtil from "../../../navigator/NavUtil";
import {CHAT_TYPE} from "../../../common/constant/Constant";

class GroupChatScreen extends React.PureComponent{
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        this.loadData();
    }

    render() {
        let {groupChat} = this.props;
        console.log(groupChat);
        if(!groupChat) {
            groupChat = {
                chatList: [],
                isLoading: false,
            }
        }
        return(
            <View style={{flex: 1,}}>
                <FlatList
                    data={groupChat.chatList}
                    renderItem={this.renderItem}
                    keyExtractor={item => item.id.toString()}
                    refreshControl={
                        <RefreshControl
                            title={"加载中..."}
                            titleColor={"#0084ff"}
                            colors={["#0084ff"]}
                            refreshing={groupChat.isLoading}
                            onRefresh={this.loadData}
                            tintColor={"#0084ff"}
                        />
                    }
                />
            </View>
        )
    };

    renderItem = ({item}) => {
        let leftAvatar =
            <Avatar
                source={{uri: item.avatar}}
                size={40}
                rounded
            />;
        let title = this.renderItemTitle(item);
        let snippet = this.renderItemSnippet(item);
        return(
            <TouchableNativeFeedback
                onPress={() => {this.toChatPage(item)}}
            >
                <View style={styles.itemContainer}>
                    {leftAvatar}
                    <View style={styles.itemRightContainer}>
                        {title}
                        {snippet}
                    </View>
                </View>
            </TouchableNativeFeedback>
        )
    };
    renderItemTitle = (item) => {
        return (
            <View style={styles.itemTitleContainer}>
                <Text
                    style={styles.itemTitle}
                    numberOfLines={1}
                    ellipsizeMode={"tail"}
                >{item.name}</Text>
                <Text
                    style={{fontSize: 14, color: "#cfcfcf"}}
                >{Util.dateTimeToDisplayString(item.snippet? item.snippet.createdAt : "")}</Text>
            </View>
        )
    };
    renderItemSnippet = (item) => {
        return (
            <View>
                <Text style={{fontSize: 13, color: "#666"}}>
                    {item.snippet? item.snippet.text + (item.snippet.image && item.snippet.image.length > 0 ? " [图片]": "") : ""}
                </Text>
            </View>
        );
    };

    loadData = () => {
        let {currentUser} = this.props;
        this.props.onGetGroupChats(currentUser);
    };
    toChatPage = (item) => {
        NavigationUtil.toPage({receiver: {
                id: item.id,
                nickname: item.name,
                avatar: item.avatar,
            }, type: CHAT_TYPE.GROUP_CHAT}, "ChatPage")
    }
}
const mapStateToProps = state => ({
    currentUser: state.currentUser,
    groupChat: state.groupChat,
});
const mapDispatchToProps = dispatch => ({
    onGetGroupChats: (currentUser) => dispatch(onGetGroupChats(currentUser)),
});

export default connect(mapStateToProps, mapDispatchToProps)(GroupChatScreen);

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    itemContainer: {
        flexDirection: "row",
        alignItems: "center",
        paddingLeft: 15,
        paddingRight: 15,
        marginTop: 12,
        marginBottom: 5,
    },
    itemRightContainer: {
        flex: 1,
        marginLeft: 15,
        borderBottomWidth: 0.5,
        borderColor: "#eee",
        paddingBottom: 12,
    },
    itemTitleContainer: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 6.
    },
    itemTitle: {
        fontSize: 15,
        color: "#4a4a4a",
        fontWeight: "800",
        flex: 1,
    },
});
