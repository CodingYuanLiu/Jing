import {
    FLUSH_GROUP_CHAT_MESSAGE,
    GET_GROUP_CHAT_HISTORY_OK, GET_GROUP_CHAT_LIST_OK,
    ON_GET_GROUP_CHAT_HISTORY, ON_GET_GROUP_CHAT_LIST,
    ON_SEND_GROUP_CHAT_MESSAGE
} from "../common/constant/ActionTypes";
import LocalApi from "../api/LocalApi";
import GroupChatApi from "../api/GroupChatApi";


const addGroupChatMessage = (message, id) => ({
    type: ON_SEND_GROUP_CHAT_MESSAGE,
    id,
    message,
});

const onGetGroupChats = (currentUser) => {
    return dispatch => {
        dispatch({
            type: ON_GET_GROUP_CHAT_LIST,
        });

        GroupChatApi.getGroupChats(currentUser)
            .then(res =>  {
                console.log(res);
                dispatch({
                    type: GET_GROUP_CHAT_LIST_OK,
                    list: res,
                })
            })
            .catch(err => {
                console.log(err);
            })
    };
};

const getGroupChatHistory = (id) => {
    return dispatch => {
        dispatch({
            type: ON_GET_GROUP_CHAT_HISTORY,
            id,
        });
        LocalApi.getGroupChatHistory(id)
            .then(res => {

                dispatch({
                    type: GET_GROUP_CHAT_HISTORY_OK,
                    history: res,
                    id,
                })
            })
            .catch(err => {
                console.log(err);
            })

    }
};

const flushGroupChatMessage = (id, message) => ({
    type: FLUSH_GROUP_CHAT_MESSAGE,
    id,
    message,
});

export {
    getGroupChatHistory,
    onGetGroupChats,
    addGroupChatMessage,
    flushGroupChatMessage,
}
