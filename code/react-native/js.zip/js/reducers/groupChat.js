
import {
    FLUSH_GROUP_CHAT_MESSAGE,
    FLUSH_PRIVATE_MESSAGE,
    GET_GROUP_CHAT_HISTORY_OK,
    ON_SEND_GROUP_CHAT_MESSAGE
} from "../common/constant/ActionTypes";
import {ON_GET_GROUP_CHAT_LIST} from "../common/constant/ActionTypes";
import {ON_GET_GROUP_CHAT_HISTORY} from "../common/constant/ActionTypes";
import {GET_GROUP_CHAT_LIST_OK} from "../common/constant/ActionTypes";

const initialState = {
    chatList: [],
    hasLoadHistory: false,
    isLoading: false,
};

const flushGroupChatMessage = (messages, message) => {
    let size = messages.length;
    for(let i = size - 1; i--; i > 0) {
        if(messages[i]._id === message._id) {
            messages[i] = message;
        }
    }
    return [...messages];
};

const groupChat = (state=initialState, action) => {
    switch (action.type) {
        case ON_SEND_GROUP_CHAT_MESSAGE:
            return {
                ...state,
                [action.id]: {
                    ...state[action.id],
                    messages: state[action.id] && state[action.id].messages?
                        [...state[action.id].messages, action.message]
                        : [action.message]
                }
            };
        case ON_GET_GROUP_CHAT_LIST:
            return {
                ...state,
                isLoading: true,
            };
        case GET_GROUP_CHAT_LIST_OK:
            console.log(action.list);
            return {
                ...state,
                isLoading: false,
                chatList: action.list,
            };
        case ON_GET_GROUP_CHAT_HISTORY:
            return {
                ...state,
                [action.id]: {
                    isLoading: true,
                }
            };
        case GET_GROUP_CHAT_HISTORY_OK:
            return {
                ...state,
                [action.id]: {
                    ...state[action.id],
                    messages: action.history.messages,
                    hasLoadHistory: true,
                }
            };
        case FLUSH_GROUP_CHAT_MESSAGE:
            console.log("props change",state[action.id]);
            return {
                ...state,
                [action.id]: {
                    ...state[action.id],
                    messages: flushGroupChatMessage(state[action.id].messages, action.message),
                }
            };
        default:
            return state;
    }

};

export default groupChat;
